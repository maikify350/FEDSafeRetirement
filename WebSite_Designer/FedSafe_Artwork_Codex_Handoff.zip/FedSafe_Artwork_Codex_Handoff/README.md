# FedSafe Retirement Artwork Codex Handoff Package

This package contains the prompt catalog and implementation handoff for a client-facing FedSafe Retirement artwork review site.

## Contents

- `CODEX_HANDOFF.md` — full implementation spec and complete prompt catalog.
- `CODEX_BUILD_PROMPT.md` — concise copy/paste prompt for Codex.
- `IMAGE_PROMPTS.md` — image-generation prompt catalog only.
- `SUNO_PROMPTS.md` — Suno instrumental prompt catalog only.
- `src/data/artworks.ts` — TypeScript seed file for the review site.
- `data/artworks.json` — JSON seed file.
- `data/artwork_index.csv` — compact index for planning/review.
- `public/artworks/generated/` — generated example images already renamed by concept ID.

## Included Generated Example Images

The package includes six generated example images already mapped in the data file:

- FS-001 — Homepage Hero Couple Reviewing Retirement Plans
- FS-003 — Air Force Officer and Spouse Reviewing Retirement Paperwork
- FS-005 — Postal-Style Federal Worker Reviewing Retirement Paperwork
- FS-006 — Federal Judge Reviewing Retirement Documents
- FS-011 — Concerned Individual Reviewing Paperwork
- FS-015 — Federal Retirement Workshop

## Suggested Next Step

Give `CODEX_BUILD_PROMPT.md` and this folder to Codex. Ask it to build the Next.js + Tailwind static review site using `src/data/artworks.ts`.

## Client Selection Workflow

The client can select concepts by ID, for example:

```text
FS-001, FS-005, FS-017, MU-001, MU-006
```

Use those IDs to generate final images, videos, or Suno music variations.
