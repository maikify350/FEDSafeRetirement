# Act! CRM Copilot — Chrome Extension

> Business Intelligence, Field Mapping & Auto-Fill for Act! CRM Web  
> Built by **MustAutomate.AI**

## Features

### ⚡ Insights Tab
- Live contact data from the Act! API (directly via `https://apius.act.com`)
- One-click enrichment — Google, LinkedIn, YouTube search
- Contact card with name, company, and contact ID

### 🔍 Fields Tab
- **Field Scanner** — Discovers all form fields on the current Act! page
- **Base64 ID Decoder** — Reveals the internal field names (e.g., `TBL_CONTACT.CUST_FEGLICodeActive...`)
- **Inline Editor** — Change any field value and apply it with proper `layoutOnChange` triggering
- **Filter** — Quickly find fields by name

### ⚙️ Rules Tab
- **Auto-Fill Rules** — Define "WHEN field X = value, SET field Y → new value"
- **Toggle rules** on/off individually
- **Run All** — Execute all active rules in one click
- Rules persist across sessions via `chrome.storage`

## Installation

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select this `ActCopilotExtension` folder
5. Navigate to any `*.act.com` page — the ⚡ COPILOT button appears in the toolbar

## Requirements

- **No local server needed.** All API calls go directly to the cloud:
  - Act! CRM API → `https://apius.act.com/act.web.api`
  - FEGLI calculation + code lookup → `https://fedsafe-retirement.vercel.app`
- Chrome extension permissions handle cross-origin access via the background service worker

## Architecture

```
ActCopilotExtension/
├── manifest.json       # v3 manifest — targets *.act.com
├── content.js          # Main UI — 3-tab drawer panel
├── field-mapper.js     # Field scanner, Base64 decoder, DOM writer
├── panel.css           # Dark glassmorphism styles
├── background.js       # Service worker for cross-origin API calls
├── icons/              # Extension icons (16, 48, 128)
└── README.md
```

## Field ID Encoding

Act! encodes DOM element IDs as Base64 strings of the internal field path:

```
Base64("TBL_CONTACT.CUST_FEGLICodeActiveE084820759")
  →  "VEJMX0NPT1RBQ1QuQ1VTVF9GRUdMSUNvZGVBY3RpdmVFMDg0ODIwNzU5"
```

| Segment | Meaning |
|---------|---------|
| `TBL_CONTACT` | Database table |
| `CUST_` | Custom field prefix (optional) |
| `FEGLICodeActive` | Field name |
| `E084820759` | Layout/schema identifier |

These IDs are **deterministic** — same across sessions, users, and PCs.

## Console API

The `ActFieldMapper` is exposed globally for debugging:

```js
// Scan all fields
ActFieldMapper.scanPage()

// Get a field value
ActFieldMapper.getFieldValue('FEGLICodeActive')

// Set a field value (triggers Act! handlers)
ActFieldMapper.setFieldValue('FEGLICodeActive', 'Z5')

// Bulk set
ActFieldMapper.setFields({ BasicLife: '152000', FEGLICodeActive: 'Z5' })

// Get full snapshot
ActFieldMapper.snapshot()

// Find fields by partial name
ActFieldMapper.findFields('FEGLI')
```
